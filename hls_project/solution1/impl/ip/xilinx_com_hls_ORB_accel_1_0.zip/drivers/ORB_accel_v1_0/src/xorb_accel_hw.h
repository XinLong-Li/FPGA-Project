// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - enable ap_done interrupt (Read/Write)
//        bit 1  - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - ap_done (COR/TOW)
//        bit 1  - ap_ready (COR/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of height
//        bit 31~0 - height[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of width
//        bit 31~0 - width[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of height_new
//        bit 31~0 - height_new[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of width_new
//        bit 31~0 - width_new[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of threshold
//        bit 31~0 - threshold[31:0] (Read/Write)
// 0x3c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XORB_ACCEL_CONTROL_ADDR_AP_CTRL         0x00
#define XORB_ACCEL_CONTROL_ADDR_GIE             0x04
#define XORB_ACCEL_CONTROL_ADDR_IER             0x08
#define XORB_ACCEL_CONTROL_ADDR_ISR             0x0c
#define XORB_ACCEL_CONTROL_ADDR_AP_RETURN       0x10
#define XORB_ACCEL_CONTROL_BITS_AP_RETURN       32
#define XORB_ACCEL_CONTROL_ADDR_HEIGHT_DATA     0x18
#define XORB_ACCEL_CONTROL_BITS_HEIGHT_DATA     32
#define XORB_ACCEL_CONTROL_ADDR_WIDTH_DATA      0x20
#define XORB_ACCEL_CONTROL_BITS_WIDTH_DATA      32
#define XORB_ACCEL_CONTROL_ADDR_HEIGHT_NEW_DATA 0x28
#define XORB_ACCEL_CONTROL_BITS_HEIGHT_NEW_DATA 32
#define XORB_ACCEL_CONTROL_ADDR_WIDTH_NEW_DATA  0x30
#define XORB_ACCEL_CONTROL_BITS_WIDTH_NEW_DATA  32
#define XORB_ACCEL_CONTROL_ADDR_THRESHOLD_DATA  0x38
#define XORB_ACCEL_CONTROL_BITS_THRESHOLD_DATA  32

