// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
`timescale 1 ns / 1 ps
module ORB_accel_process_rBRIEF_8_1080_1920_s_img_line_val_V_0_ram (addr1, ce1, d1, we1,  clk);

parameter DWIDTH = 8;
parameter AWIDTH = 11;
parameter MEM_SIZE = 1920;

input[AWIDTH-1:0] addr1;
input ce1;
input[DWIDTH-1:0] d1;
input we1;
input clk;

(* ram_style = "block" *)reg [DWIDTH-1:0] ram[0:MEM_SIZE-1];




always @(posedge clk)  
begin 
    if (ce1) begin
        if (we1) 
            ram[addr1] <= d1; 
    end
end


endmodule

`timescale 1 ns / 1 ps
module ORB_accel_process_rBRIEF_8_1080_1920_s_img_line_val_V_0(
    reset,
    clk,
    address1,
    ce1,
    we1,
    d1);

parameter DataWidth = 32'd8;
parameter AddressRange = 32'd1920;
parameter AddressWidth = 32'd11;
input reset;
input clk;
input[AddressWidth - 1:0] address1;
input ce1;
input we1;
input[DataWidth - 1:0] d1;



ORB_accel_process_rBRIEF_8_1080_1920_s_img_line_val_V_0_ram ORB_accel_process_rBRIEF_8_1080_1920_s_img_line_val_V_0_ram_U(
    .clk( clk ),
    .addr1( address1 ),
    .ce1( ce1 ),
    .we1( we1 ),
    .d1( d1 ));

endmodule

